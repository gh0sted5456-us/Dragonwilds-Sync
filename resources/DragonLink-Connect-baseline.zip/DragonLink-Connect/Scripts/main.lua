---@diagnostic disable: undefined-global

local TAG = "[DragonLink-Connect]"
local VERSION = "0.6.0"
local EDITABLE_TEXT_CLASS = "/Script/UMG.EditableText"

local source = debug.getinfo(1, "S").source or ""
if source:sub(1, 1) == "@" then source = source:sub(2) end
local script_dir = source:match("^(.*)[/\\]") or "."
local diagnostic_path = script_dir .. "\\diagnostic.log"

-- Load optional config file (config.lua) if present
local config = {}
do
  local ok, cfg = pcall(dofile, script_dir .. "\\config.lua")
  if ok and type(cfg) == "table" then
    config = cfg
  end
end
local saved_address = ""
local server_type = config.SERVER_TYPE or "normal"
local world_type = string.lower(tostring(config.WORLD_TYPE or server_type or "normal"))
if world_type == "hardcore" then world_type = "custom" end
if world_type ~= "normal" and world_type ~= "custom" and world_type ~= "creative" then
    world_type = "normal"
end
-- A panel visit owns fresh widget objects. Weak object keys guarantee one
-- handoff per actual Direct Connect screen instance without retaining dead
-- widgets or suppressing a later visit that happens to reuse the same name.
local restored_objects = setmetatable({}, { __mode = "k" })
local restored_password_objects = setmetatable({}, { __mode = "k" })
local restored_world_type_objects = setmetatable({}, { __mode = "k" })

local function append_diagnostic(message)
    if not config.ENABLE_DIAGNOSTIC_LOG then return end
    local file = io.open(diagnostic_path, "a")
    if file then
        file:write(os.date("%Y-%m-%d %H:%M:%S") .. " " .. message .. "\n")
        file:close()
    end
end

local function log(message)
    local line = TAG .. " " .. tostring(message)
    print(line .. "\n")
    append_diagnostic(line)
end

local function trim(value)
    if type(value) ~= "string" then return "" end
    return value:match("^%s*(.-)%s*$") or ""
end

local function is_valid(object)
    if object == nil then return false end
    local ok, result = pcall(function() return object:IsValid() end)
    return ok and result == true
end

local function full_name(object)
    if not is_valid(object) then return "<invalid>" end
    local ok, value = pcall(function() return object:GetFullName() end)
    if ok and type(value) == "string" then return value end
    return "<GetFullName failed>"
end

local function candidate_matches(name)
    local lower = string.lower(name or "")
    if string.find(lower, "default__", 1, true) then return false end
    return string.find(lower, "directpanel", 1, true) ~= nil
        and string.find(lower, "ipaddress", 1, true) ~= nil
        and string.find(lower, "editabletext", 1, true) ~= nil
end

local function parse_ipv4(host)
    local count = 0
    for octet in host:gmatch("[^.]+") do
        count = count + 1
        if not octet:match("^%d+$") then return false end
        if #octet > 1 and octet:sub(1, 1) == "0" then
            -- Leading zeroes are accepted by some parsers, but rejecting them
            -- prevents ambiguous addresses and accidental partial saves.
            return false
        end
        local number = tonumber(octet)
        if number == nil or number < 0 or number > 255 then return false end
    end
    return count == 4
end

local function is_valid_hostname(host)
    if #host < 1 or #host > 253 then return false end
    if not host:find("%.") then return false end
    if host:sub(1, 1) == "." or host:sub(-1) == "." then return false end
    for label in host:gmatch("[^.]+") do
        if #label < 1 or #label > 63 then return false end
        if not label:match("^[%w%-]+$") then return false end
        if label:sub(1, 1) == "-" or label:sub(-1) == "-" then return false end
    end
    return true
end

local function normalize_server_address(value)
    value = trim(value)
    if value == "" or #value > 300 then return nil, "empty or oversized value" end
    if value:find("%s") then return nil, "contains whitespace" end

    local host = value
    local port = nil

    -- IPv6 is intentionally not handled in this first reflection test build.
    local parsed_host, parsed_port = value:match("^([^:]+):(%d+)$")
    if parsed_host then
        host = parsed_host
        port = tonumber(parsed_port)
        if port == nil or port < 1 or port > 65535 then
            return nil, "invalid port"
        end
    elseif value:find(":", 1, true) then
        return nil, "unsupported address format"
    end

    if not parse_ipv4(host) and not is_valid_hostname(host) then
        return nil, "not a complete IPv4 address or hostname"
    end

    if port then return host .. ":" .. tostring(port), nil end
    return host, nil
end

local function read_saved_address()
    if config.IP and config.IP ~= "" then
        local normalized, err = normalize_server_address(config.IP)
        return normalized or ""
    end
    return ""
end

local function read_text_value(editable)
    if not is_valid(editable) then return "", "invalid EditableText" end
    local ok_get, text_value = pcall(function() return editable:GetText() end)
    if not ok_get or text_value == nil then return "", "GetText failed" end
    local ok_string, value = pcall(function() return text_value:ToString() end)
    if not ok_string or type(value) ~= "string" then return "", "FText ToString failed" end
    return trim(value), nil
end

local function import_text_property(editable, value)
    if not is_valid(editable) then return false, "invalid EditableText" end

    local normalized, validation_error = normalize_server_address(value)
    if not normalized then return false, validation_error end

    local ok, result = pcall(function()
        local property = editable:Reflection():GetProperty("Text")
        if not is_valid(property) then
            error("reflected Text property is invalid")
        end
        property:ImportText(
            normalized,
            property:ContainerPtrToValuePtr(editable),
            0,
            editable
        )
    end)

    if not ok then return false, tostring(result) end
    return true, nil
end

local function restore_editable(editable, reason, force)
    if saved_address == "" then return false, "no valid saved address" end
    if not is_valid(editable) then return false, "no live IP EditableText" end

    local name = full_name(editable)
    if not force and restored_objects[editable] then return false, "already attempted" end

    local current, read_error = read_text_value(editable)
    if not force and current ~= "" then
        restored_objects[editable] = true
        return false, "field already contains '" .. current .. "'"
    end

    restored_objects[editable] = true
    local imported, import_error = import_text_property(editable, saved_address)
    if not imported then return false, import_error end

    local after, after_error = read_text_value(editable)
    log("ImportText restore attempted via " .. reason
        .. "; readback_match=" .. tostring(after == saved_address)
        .. (after_error and ("; readback_error=" .. after_error) or ""))

    return after == saved_address, after == saved_address and nil or "property imported but visible/readback value did not update"
end

os.remove(diagnostic_path)
saved_address = read_saved_address()
log("Version " .. VERSION .. " loaded")
log(saved_address ~= "" and "Validated profile address loaded" or "No profile address configured")
log("Restore method: reflected EditableText.Text Property:ImportText")
log("Lifecycle: dormant outside Direct Connect; each panel widget is written at most once")

-- Attempt restoration as soon as the specific runtime EditableText object is created.
local notify_ok, notify_error = pcall(function()
    NotifyOnNewObject(EDITABLE_TEXT_CLASS, function(object)
        if not is_valid(object) or not candidate_matches(full_name(object)) then return end
        log("Observed Direct Connect EditableText creation: " .. full_name(object))
        -- The owning Blueprint binds Text just after construction. Perform one
        -- bounded handoff after initialization and never touch this widget again.
        local scheduled = pcall(function()
            ExecuteInGameThreadWithDelay(180, function()
                local restored, restore_error = restore_editable(object, "Direct Connect panel ready", false)
                if not restored and restore_error ~= "already attempted" then
                    log("Creation-time restore result: " .. tostring(restore_error))
                end
            end)
        end)
        if not scheduled then
            restore_editable(object, "Direct Connect creation fallback", false)
        end
    end)
end)
if notify_ok then
    log("Registered EditableText creation observer")
else
    log("Failed to register EditableText creation observer: " .. tostring(notify_error))
end


-- The Direct screen's World Type is a UMG ComboBoxString. Dragonwilds uses
-- Normal, Custom, and Creative labels; Sync's Hardcore classification is a
-- customized ruleset and is therefore handed to the game as Custom.
local WORLD_TYPE_CLASS = "/Script/UMG.ComboBoxString"
local world_type_labels = {
    normal = "Normal",
    custom = "Custom",
    creative = "Creative"
}

local function world_type_candidate_matches(name)
    local lower = string.lower(name or "")
    if string.find(lower, "default__", 1, true) then return false end
    local direct_ui = string.find(lower, "directpanel", 1, true) ~= nil
        or string.find(lower, "worldsdirect", 1, true) ~= nil
        or string.find(lower, "mainmenu_worlds_direct", 1, true) ~= nil
    -- This observer only receives ComboBoxString objects. The Direct panel has
    -- one such selector, and some game builds omit "WorldType" from its name.
    return direct_ui
end

local function selected_world_type(selector)
    local ok, value = pcall(function() return selector:GetSelectedOption() end)
    if not ok or value == nil then return "" end
    return string.lower(trim(tostring(value)))
end

local function restore_world_type(selector, reason)
    if not is_valid(selector) or not world_type_candidate_matches(full_name(selector)) then
        return false, "not the Direct World Type selector"
    end
    local name = full_name(selector)
    if restored_world_type_objects[selector] then return false, "already attempted" end
    local label = world_type_labels[world_type] or world_type_labels.normal
    local ok, err = pcall(function()
        selector:SetSelectedOption(label)
        pcall(function() selector:SynchronizeProperties() end)
    end)
    local after = selected_world_type(selector)
    local committed = ok and after == string.lower(label)
    if committed then restored_world_type_objects[selector] = true end
    log("World Type handoff via " .. reason .. "; field=" .. name
        .. "; requested=" .. label
        .. "; committed=" .. tostring(committed)
        .. "; readback=" .. tostring(after)
        .. (ok and "" or ("; error=" .. tostring(err))))
    return committed, committed and nil or "selection did not commit"
end

local function restore_existing_world_type_selectors(reason)
    local restored = 0
    local ok, objects = pcall(FindAllOf, "ComboBoxString")
    if ok and type(objects) == "table" then
        for _, object in ipairs(objects) do
            local committed = restore_world_type(object, reason)
            if committed then restored = restored + 1 end
        end
    end
    return restored
end

local world_type_notify_ok, world_type_notify_error = pcall(function()
    NotifyOnNewObject(WORLD_TYPE_CLASS, function(object)
        if not is_valid(object) or not world_type_candidate_matches(full_name(object)) then return end
        -- Combo options are populated by the owning Blueprint after object
        -- construction, so apply exactly once after initialization.
        local scheduled = pcall(function()
            ExecuteInGameThreadWithDelay(250, function()
                restore_world_type(object, "DragonLink-Connect widget-ready")
            end)
        end)
        if not scheduled then
            restore_world_type(object, "DragonLink-Connect creation fallback")
        end
    end)
end)
if world_type_notify_ok then
    log("Direct World Type selector observer registered; requested="
        .. tostring(world_type_labels[world_type]))
else
    log("World Type selector observer unavailable: " .. tostring(world_type_notify_error))
end
local initial_world_type_restores = restore_existing_world_type_selectors("startup scan")
log("Startup World Type scan committed " .. tostring(initial_world_type_restores) .. " selector(s)")


-- Dragonwilds Sync profile extension v0.4.1 ------------------------------
-- The launcher writes last_password.txt only after the player has already
-- authenticated to that World. It remains local beside the generated config.
local profile_password_path = script_dir .. "\\last_password.txt"

local function password_candidate_matches(name)
    local lower = string.lower(name or "")
    if string.find(lower, "default__", 1, true) then return false end
    local password_field = string.find(lower, "password", 1, true) ~= nil
        or string.find(lower, "passcode", 1, true) ~= nil
        or string.find(lower, "worldpass", 1, true) ~= nil
    local world_join_ui = string.find(lower, "directpanel", 1, true) ~= nil
        or string.find(lower, "mainmenu_worlds", 1, true) ~= nil
        or string.find(lower, "startmenu", 1, true) ~= nil
    return password_field and world_join_ui
        and string.find(lower, "editabletext", 1, true) ~= nil
end

local function read_profile_password()
    if config.PASSWORD and config.PASSWORD ~= "" then
        local val = config.PASSWORD
        if #val > 512 then return "" end
        return val
    end
    local file = io.open(profile_password_path, "r")
    if not file then return "" end
    local value = file:read("*a") or ""
    file:close()
    value = value:gsub("[\r\n]+$", "")
    if #value > 512 then return "" end
    return value
end

local function restore_profile_password(editable, reason)
    local value = read_profile_password()
    if value == "" or not is_valid(editable) then return false end
    local name = full_name(editable)
    if restored_password_objects[editable] then return false end
    -- ImportText changes the reflected property but can leave UMG's live
    -- Slate value/bound model untouched. SetText(FText) is the public widget
    -- function and makes the value used by the Join action match what is
    -- visibly rendered in the password box.
    local set_ok, set_error = pcall(function()
        editable:SetText(FText(value))
        pcall(function() editable:SynchronizeProperties() end)
    end)
    if not set_ok then
        local import_ok, import_error = pcall(function()
            local property = editable:Reflection():GetProperty("Text")
            if not is_valid(property) then error("reflected Text property is invalid") end
            property:ImportText(value, property:ContainerPtrToValuePtr(editable), 0, editable)
            pcall(function() editable:SynchronizeProperties() end)
        end)
        set_ok = import_ok
        set_error = import_error
    end
    local readback, readback_error = read_text_value(editable)
    local committed = set_ok and readback == value
    if committed then restored_password_objects[editable] = true end
    log("World password handoff via " .. reason .. "; field=" .. name
        .. "; committed=" .. tostring(committed)
        .. "; readback_match=" .. tostring(readback == value)
        .. (set_ok and "" or ("; error=" .. tostring(set_error)))
        .. (readback_error and ("; readback_error=" .. tostring(readback_error)) or ""))
    return committed
end

local function restore_existing_password_fields(reason)
    local restored = 0
    for _, class_name in ipairs({"EditableText", "EditableTextBox"}) do
        local ok, objects = pcall(FindAllOf, class_name)
        if ok and type(objects) == "table" then
            for _, object in ipairs(objects) do
                if is_valid(object) and password_candidate_matches(full_name(object)) then
                    if restore_profile_password(object, reason .. " " .. class_name) then
                        restored = restored + 1
                    end
                end
            end
        end
    end
    return restored
end

local function observe_password_class(class_path)
    return pcall(function()
        NotifyOnNewObject(class_path, function(object)
            if not is_valid(object) or not password_candidate_matches(full_name(object)) then return end
            -- UMG bindings can replace Text during construction. Defer one
            -- bounded handoff until the widget is live, then never rewrite
            -- that object again while the panel remains open.
            local scheduled = pcall(function()
                ExecuteInGameThreadWithDelay(150, function()
                    restore_profile_password(object, "DragonLink-Connect widget-ready " .. class_path)
                end)
            end)
            if not scheduled then
                restore_profile_password(object, "DragonLink-Connect creation fallback " .. class_path)
            end
        end)
    end)
end

local password_notify_ok, password_notify_error = observe_password_class(EDITABLE_TEXT_CLASS)
local password_box_ok, password_box_error = observe_password_class("/Script/UMG.EditableTextBox")
if password_notify_ok or password_box_ok then
    log("DragonLink-Connect password-field observer registered; EditableText="
        .. tostring(password_notify_ok) .. "; EditableTextBox=" .. tostring(password_box_ok))
else
    log("Password-field observers unavailable: " .. tostring(password_notify_error)
        .. "; " .. tostring(password_box_error))
end

-- The Direct panel can already exist before NotifyOnNewObject is registered.
-- A startup scan covers that case. Per-object tracking prevents polling or
-- repeated writes to fields while the player is typing.
local initial_restores = restore_existing_password_fields("startup scan")
log("Startup password-field scan committed " .. tostring(initial_restores) .. " field(s)")
