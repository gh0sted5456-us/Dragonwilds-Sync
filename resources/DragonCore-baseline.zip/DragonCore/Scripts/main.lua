-- ========================================================
-- DragonCore v4.2.0 Classic
-- Stacks + weights, with natural item classification.
-- ========================================================

---@diagnostic disable: undefined-global

local Core = {
    Name = "DragonCore",
    Prefix = "[DragonCore] ",
    Version = "4.2.0-classic",
    Config = {},
    StackConfig = {},
    WeightConfig = {},
    HookIds = {},
    HookRetryGeneration = 0,
    ObserverInstalled = false,

    -- Runtime-only originals. Weak keys mean ItemData can still be collected.
    -- This is NOT a persistent cache and is never written to disk.
    OriginalValues = setmetatable({}, { __mode = "k" }),
}

function Core:Log(message)
    print(self.Prefix .. tostring(message))
end

function Core:Debug(message)
    if self.Config.Debug == true then self:Log("DEBUG: " .. tostring(message)) end
end

function Core:IsValid(object)
    if not object then return false end
    local ok, result = pcall(function() return object:IsValid() end)
    return ok and result == true
end

local function safeRequire(name, fallback)
    package.loaded[name] = nil
    local ok, result = pcall(require, name)
    if ok and type(result) == "table" then return result end
    Core:Log("WARNING: could not load " .. tostring(name) .. "; using fallback.")
    return fallback or {}
end

Core.Config = safeRequire("config", {
    Enabled = true,
    Mode = "Player",
    Stacks = true,
    Weights = true,
    Debug = false,
})

Core.StackConfig = safeRequire("stacks", {
    Defaults = { Vanilla = 300, Modded = 300 },
    Equipment = { Enabled = false, StackSize = 1 },
    Rules = {},
    Custom = {},
})

Core.WeightConfig = safeRequire("weights", {
    ZeroWeightNonEquipment = false,
    Defaults = { Vanilla = 0.0, Modded = 0.0 },
    Equipment = {},
    Custom = {},
})

local Classifier = safeRequire("modules.core.classifier")
if Classifier.Attach then Classifier.Attach(Core) end

local Network = safeRequire("modules.core.network")
if Network.Attach then Network.Attach(Core) end

local Stacks = safeRequire("modules.features.stacks")
local Weights = safeRequire("modules.features.weights")

if Stacks.Prepare then Stacks.Prepare(Core) end
if Weights.Prepare then Weights.Prepare(Core) end

function Core:RememberOriginal(ItemData, propertyName, value)
    if not self:IsValid(ItemData) or value == nil then return end
    local row = self.OriginalValues[ItemData]
    if not row then
        row = {}
        self.OriginalValues[ItemData] = row
    end
    if row[propertyName] == nil then row[propertyName] = value end
end

function Core:RestoreOriginalValues()
    local restored = 0
    for itemData, values in pairs(self.OriginalValues) do
        if self:IsValid(itemData) then
            if values.MaxStackSize ~= nil then
                pcall(function() itemData.MaxStackSize = values.MaxStackSize end)
                if itemData.SetPropertyValue then
                    pcall(function() itemData:SetPropertyValue("MaxStackSize", values.MaxStackSize) end)
                end
            end
            if values.Weight ~= nil then
                pcall(function() itemData.Weight = values.Weight end)
                if itemData.SetPropertyValue then
                    pcall(function() itemData:SetPropertyValue("Weight", values.Weight) end)
                    pcall(function() itemData:SetPropertyValue("ItemWeight", values.Weight) end)
                end
            end
            restored = restored + 1
        end
    end
    self.OriginalValues = setmetatable({}, { __mode = "k" })
    self:Debug("restored original values for " .. tostring(restored) .. " loaded ItemData")
end

function Core:ApplyItemData(ItemData)
    if not self:ShouldModify() or not self:IsValid(ItemData) then return false end
    local changed = false

    if self.Config.Stacks ~= false and Stacks.PatchItemData then
        local ok, result = pcall(Stacks.PatchItemData, ItemData, self)
        if ok and result then changed = true end
    end

    if self.Config.Weights ~= false and Weights.PatchItemData then
        local ok, result = pcall(Weights.PatchItemData, ItemData, self)
        if ok and result then changed = true end
    end

    return changed
end

-- Patch ItemData Unreal has actually loaded. No catalog, no PAK scan, no disk cache.
function Core:PatchLoadedItemData()
    if not self:ShouldModify() then return 0 end
    local seen = setmetatable({}, { __mode = "k" })
    local count = 0

    for _, className in ipairs({ "ItemData", "ConsumableItemData" }) do
        local ok, objects = pcall(FindAllOf, className)
        if ok and type(objects) == "table" then
            for _, object in ipairs(objects) do
                if self:IsValid(object) and not seen[object] then
                    seen[object] = true
                    self:ApplyItemData(object)
                    count = count + 1
                end
            end
        end
    end

    self:Debug("loaded ItemData sweep: " .. tostring(count))
    return count
end

function Core:RegisterStackHook(path, callback)
    if self.HookIds[path] then return true end
    if type(RegisterHook) ~= "function" then return false end

    local ok, preId, postId = pcall(RegisterHook, path, callback)
    if ok and preId ~= nil and postId ~= nil then
        self.HookIds[path] = { Pre = preId, Post = postId }
        self:Log("Hook registered: " .. path)
        return true
    end
    return false
end

function Core:EnsureStackHooks()
    if self.Config.Enabled == false or self.Config.Stacks == false then return true end
    if Stacks.RegisterHooks then Stacks.RegisterHooks(self) end

    return self.HookIds["/Script/Dominion.Item:SetStackSize"] ~= nil
        and self.HookIds["/Script/Dominion.ItemData:GetMaxStackSize"] ~= nil
        and self.HookIds["/Script/Dominion.Item:GetStackFreeSpace"] ~= nil
end

function Core:RetryStartupHooks(attempt, generation)
    if generation ~= self.HookRetryGeneration then return end
    if self:EnsureStackHooks() then
        self:Log("Stack hooks ready.")
        return
    end

    if (attempt or 0) >= 45 then
        self:Log("WARNING: not all stack hooks became available during startup.")
        return
    end

    local delayFn = ExecuteInGameThreadWithDelay or ExecuteWithDelay
    if type(delayFn) == "function" then
        delayFn(1000, function() Core:RetryStartupHooks((attempt or 0) + 1, generation) end)
    end
end

function Core:InstallItemObserver()
    if self.ObserverInstalled or type(NotifyOnNewObject) ~= "function" then return end

    local function onItemData(itemData)
        if Core:ShouldModify() then Core:ApplyItemData(itemData) end
    end

    pcall(NotifyOnNewObject, "/Script/Dominion.ItemData", onItemData)
    pcall(NotifyOnNewObject, "/Script/Dominion.ConsumableItemData", onItemData)
    self.ObserverInstalled = true
end

function Core:Boot()
    self:Log("v" .. self.Version .. " starting.")
    self:Log("Features: stacks + weights only.")

    self:InstallItemObserver()

    self.HookRetryGeneration = self.HookRetryGeneration + 1
    self:RetryStartupHooks(0, self.HookRetryGeneration)

    self:StartNetworkGate()

    self:Log("No persistent item cache, registry, PAK scanner, census, recovery, or reports.")
end

Core:Boot()
return Core
