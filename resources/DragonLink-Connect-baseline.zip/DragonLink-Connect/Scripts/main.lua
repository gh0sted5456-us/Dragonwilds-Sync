---@diagnostic disable: undefined-global

local TAG = "[DragonLink-Connect]"
local VERSION = "0.4.3"
local TEXT_CHANGED_PATH = "/Script/Dominion.MainMenuWorldsDirectWidget:OnTextChanged"
local EDITABLE_TEXT_CLASS = "/Script/UMG.EditableText"

local source = debug.getinfo(1, "S").source or ""
if source:sub(1, 1) == "@" then source = source:sub(2) end
local script_dir = source:match("^(.*)[/\\]") or "."
local save_path = script_dir .. "\\last_server.txt"
local diagnostic_path = script_dir .. "\\diagnostic.log"

-- Load optional config file (config.lua) if present
local config = {}
do
  local ok, cfg = pcall(dofile, script_dir .. "\\config.lua")
  if ok and type(cfg) == "table" then
    config = cfg
  end
end
local saved_address = ""
local server_type = config.SERVER_TYPE or "normal"
local restored_objects = {}
local restored_password_objects = {}

local function append_diagnostic(message)
    if not config.ENABLE_DIAGNOSTIC_LOG then return end
    local file = io.open(diagnostic_path, "a")
    if file then
        file:write(os.date("%Y-%m-%d %H:%M:%S") .. " " .. message .. "\n")
        file:close()
    end
end

local function log(message)
    local line = TAG .. " " .. tostring(message)
    print(line .. "\n")
    append_diagnostic(line)
end

local function trim(value)
    if type(value) ~= "string" then return "" end
    return value:match("^%s*(.-)%s*$") or ""
end

local function is_valid(object)
    if object == nil then return false end
    local ok, result = pcall(function() return object:IsValid() end)
    return ok and result == true
end

local function full_name(object)
    if not is_valid(object) then return "<invalid>" end
    local ok, value = pcall(function() return object:GetFullName() end)
    if ok and type(value) == "string" then return value end
    return "<GetFullName failed>"
end

local function candidate_matches(name)
    local lower = string.lower(name or "")
    if string.find(lower, "default__", 1, true) then return false end
    return string.find(lower, "directpanel", 1, true) ~= nil
        and string.find(lower, "ipaddress", 1, true) ~= nil
        and string.find(lower, "editabletext", 1, true) ~= nil
end

local function parse_ipv4(host)
    local count = 0
    for octet in host:gmatch("[^.]+") do
        count = count + 1
        if not octet:match("^%d+$") then return false end
        if #octet > 1 and octet:sub(1, 1) == "0" then
            -- Leading zeroes are accepted by some parsers, but rejecting them
            -- prevents ambiguous addresses and accidental partial saves.
            return false
        end
        local number = tonumber(octet)
        if number == nil or number < 0 or number > 255 then return false end
    end
    return count == 4
end

local function is_valid_hostname(host)
    if #host < 1 or #host > 253 then return false end
    if not host:find("%.") then return false end
    if host:sub(1, 1) == "." or host:sub(-1) == "." then return false end
    for label in host:gmatch("[^.]+") do
        if #label < 1 or #label > 63 then return false end
        if not label:match("^[%w%-]+$") then return false end
        if label:sub(1, 1) == "-" or label:sub(-1) == "-" then return false end
    end
    return true
end

local function normalize_server_address(value)
    value = trim(value)
    if value == "" or #value > 300 then return nil, "empty or oversized value" end
    if value:find("%s") then return nil, "contains whitespace" end

    local host = value
    local port = nil

    -- IPv6 is intentionally not handled in this first reflection test build.
    local parsed_host, parsed_port = value:match("^([^:]+):(%d+)$")
    if parsed_host then
        host = parsed_host
        port = tonumber(parsed_port)
        if port == nil or port < 1 or port > 65535 then
            return nil, "invalid port"
        end
    elseif value:find(":", 1, true) then
        return nil, "unsupported address format"
    end

    if not parse_ipv4(host) and not is_valid_hostname(host) then
        return nil, "not a complete IPv4 address or hostname"
    end

    if port then return host .. ":" .. tostring(port), nil end
    return host, nil
end

local function read_saved_address()
    if not config.ENABLE_LAST_SERVER then return "" end
    if config.IP and config.IP ~= "" then
        local normalized, err = normalize_server_address(config.IP)
        return normalized or ""
    end
    local file = io.open(save_path, "r")
    if not file then return "" end
    local value = trim(file:read("*a") or "")
    file:close()
    local normalized = normalize_server_address(value)
    return normalized or ""
end

local function write_saved_address(value)
    local normalized, validation_error = normalize_server_address(value)
    if not normalized then return false, validation_error end
    if normalized == saved_address then return false, "unchanged value" end

    -- Write directly to the final path. This deliberately avoids rename and
    -- backup behavior because last_server.txt is a small, recoverable value,
    -- and direct creation is more reliable across Windows installations.
    local file, open_error = io.open(save_path, "w")
    if not file then return false, "open failed: " .. tostring(open_error) end

    local ok, write_error = pcall(function()
        file:write(normalized)
        file:flush()
        file:close()
    end)
    if not ok then
        pcall(function() file:close() end)
        return false, "write failed: " .. tostring(write_error)
    end

    saved_address = normalized
    return true, nil
end

local function read_text_value(editable)
    if not is_valid(editable) then return "", "invalid EditableText" end
    local ok_get, text_value = pcall(function() return editable:GetText() end)
    if not ok_get or text_value == nil then return "", "GetText failed" end
    local ok_string, value = pcall(function() return text_value:ToString() end)
    if not ok_string or type(value) ~= "string" then return "", "FText ToString failed" end
    return trim(value), nil
end

local function find_live_ip_editable()
    local ok, objects = pcall(FindAllOf, "EditableText")
    if not ok or type(objects) ~= "table" then return nil end
    for _, object in ipairs(objects) do
        if is_valid(object) and candidate_matches(full_name(object)) then
            return object
        end
    end
    return nil
end

local function import_text_property(editable, value)
    if not is_valid(editable) then return false, "invalid EditableText" end

    local normalized, validation_error = normalize_server_address(value)
    if not normalized then return false, validation_error end

    local ok, result = pcall(function()
        local property = editable:Reflection():GetProperty("Text")
        if not is_valid(property) then
            error("reflected Text property is invalid")
        end
        property:ImportText(
            normalized,
            property:ContainerPtrToValuePtr(editable),
            0,
            editable
        )
    end)

    if not ok then return false, tostring(result) end
    return true, nil
end

local function restore_editable(editable, reason, force)
    if saved_address == "" then return false, "no valid saved address" end
    if not is_valid(editable) then return false, "no live IP EditableText" end

    local name = full_name(editable)
    if not force and restored_objects[name] then return false, "already attempted" end

    local current, read_error = read_text_value(editable)
    if not force and current ~= "" then
        restored_objects[name] = true
        return false, "field already contains '" .. current .. "'"
    end

    restored_objects[name] = true
    local imported, import_error = import_text_property(editable, saved_address)
    if not imported then return false, import_error end

    local after, after_error = read_text_value(editable)
    log("ImportText restore attempted via " .. reason
        .. "; readback_match=" .. tostring(after == saved_address)
        .. (after_error and ("; readback_error=" .. after_error) or ""))

    return after == saved_address, after == saved_address and nil or "property imported but visible/readback value did not update"
end

local function get_context_object(context)
    if context == nil then return nil end
    local ok, object = pcall(function() return context:get() end)
    if ok and is_valid(object) then return object end
    return nil
end

local function save_from_live_field(reason, editable)
    -- OnTextChanged already supplies the exact widget that changed. Reusing
    -- that object avoids a global FindAllOf scan for every character typed.
    -- The bounded lookup remains only as a compatibility fallback for older
    -- hook builds that do not expose their context UObject.
    if not is_valid(editable) or not candidate_matches(full_name(editable)) then
        editable = find_live_ip_editable()
    end
    if not is_valid(editable) then
        log("Save skipped via " .. reason .. ": no live Direct Connect EditableText")
        return
    end

    local value, read_error = read_text_value(editable)
    if value == "" then
        log("Save skipped via " .. reason .. ": " .. tostring(read_error or "empty field"))
        return
    end

    local wrote, save_error = write_saved_address(value)
    if wrote then
        log("Saved complete validated server address via " .. reason)
    elseif save_error ~= "unchanged value" then
        log("Save rejected via " .. reason .. ": " .. tostring(save_error))
    end
end

os.remove(diagnostic_path)
saved_address = read_saved_address()
log("Version " .. VERSION .. " loaded")
log("Save path: " .. save_path)
log(saved_address ~= "" and "Validated saved address loaded at startup" or "No valid saved address found at startup")
log("Restore method: reflected EditableText.Text Property:ImportText")
log("Save method: OnTextChanged readback, but only complete validated addresses are persisted")

-- Save only once the field contains a complete valid address. This keeps the
-- stable, verified Dragonwilds hook while preventing partial keystrokes and
-- console commands from overwriting last_server.txt.
local function post_text_changed(context)
    local context_object = get_context_object(context)
    if not is_valid(context_object) then
        log("OnTextChanged fired without a valid context UObject")
        return
    end
    save_from_live_field("OnTextChanged", context_object)
end

local hook_ok, pre_id, post_id = pcall(RegisterHook, TEXT_CHANGED_PATH, function() end, post_text_changed)
if not hook_ok or pre_id == nil then
    error(TAG .. " failed to register OnTextChanged: " .. tostring(pre_id))
end
log("Registered OnTextChanged save hook ids=" .. tostring(pre_id) .. "," .. tostring(post_id))

-- Attempt restoration as soon as the specific runtime EditableText object is created.
local notify_ok, notify_error = pcall(function()
    NotifyOnNewObject(EDITABLE_TEXT_CLASS, function(object)
        if not is_valid(object) or not candidate_matches(full_name(object)) then return end
        log("Observed Direct Connect EditableText creation: " .. full_name(object))
        local restored, restore_error = restore_editable(object, "NotifyOnNewObject", false)
        if not restored and restore_error ~= "already attempted" then
            log("Creation-time restore result: " .. tostring(restore_error))
        end
    end)
end)
if notify_ok then
    log("Registered EditableText creation observer")
else
    log("Failed to register EditableText creation observer: " .. tostring(notify_error))
end


-- Dragonwilds Sync profile extension v0.4.1 ------------------------------
-- The launcher writes last_password.txt only after the player has already
-- authenticated to that World. It remains local beside last_server.txt.
local profile_password_path = script_dir .. "\\last_password.txt"

local function password_candidate_matches(name)
    local lower = string.lower(name or "")
    if string.find(lower, "default__", 1, true) then return false end
    local password_field = string.find(lower, "password", 1, true) ~= nil
        or string.find(lower, "passcode", 1, true) ~= nil
        or string.find(lower, "worldpass", 1, true) ~= nil
    local world_join_ui = string.find(lower, "directpanel", 1, true) ~= nil
        or string.find(lower, "mainmenu_worlds", 1, true) ~= nil
        or string.find(lower, "startmenu", 1, true) ~= nil
    return password_field and world_join_ui
        and string.find(lower, "editabletext", 1, true) ~= nil
end

local function read_profile_password()
    if config.PASSWORD and config.PASSWORD ~= "" then
        local val = config.PASSWORD
        if #val > 512 then return "" end
        return val
    end
    local file = io.open(profile_password_path, "r")
    if not file then return "" end
    local value = file:read("*a") or ""
    file:close()
    value = value:gsub("[\r\n]+$", "")
    if #value > 512 then return "" end
    return value
end

local function restore_profile_password(editable, reason)
    local value = read_profile_password()
    if value == "" or not is_valid(editable) then return false end
    local name = full_name(editable)
    if restored_password_objects[name] then return false end
    -- ImportText changes the reflected property but can leave UMG's live
    -- Slate value/bound model untouched. SetText(FText) is the public widget
    -- function and makes the value used by the Join action match what is
    -- visibly rendered in the password box.
    local set_ok, set_error = pcall(function()
        editable:SetText(FText(value))
        pcall(function() editable:SynchronizeProperties() end)
    end)
    if not set_ok then
        local import_ok, import_error = pcall(function()
            local property = editable:Reflection():GetProperty("Text")
            if not is_valid(property) then error("reflected Text property is invalid") end
            property:ImportText(value, property:ContainerPtrToValuePtr(editable), 0, editable)
            pcall(function() editable:SynchronizeProperties() end)
        end)
        set_ok = import_ok
        set_error = import_error
    end
    local readback, readback_error = read_text_value(editable)
    local committed = set_ok and readback == value
    if committed then restored_password_objects[name] = true end
    log("World password handoff via " .. reason .. "; field=" .. name
        .. "; committed=" .. tostring(committed)
        .. "; readback_match=" .. tostring(readback == value)
        .. (set_ok and "" or ("; error=" .. tostring(set_error)))
        .. (readback_error and ("; readback_error=" .. tostring(readback_error)) or ""))
    return committed
end

local function restore_existing_password_fields(reason)
    local restored = 0
    for _, class_name in ipairs({"EditableText", "EditableTextBox"}) do
        local ok, objects = pcall(FindAllOf, class_name)
        if ok and type(objects) == "table" then
            for _, object in ipairs(objects) do
                if is_valid(object) and password_candidate_matches(full_name(object)) then
                    if restore_profile_password(object, reason .. " " .. class_name) then
                        restored = restored + 1
                    end
                end
            end
        end
    end
    return restored
end

local function observe_password_class(class_path)
    return pcall(function()
        NotifyOnNewObject(class_path, function(object)
            if not is_valid(object) or not password_candidate_matches(full_name(object)) then return end
            -- UMG bindings can replace Text during construction. Defer one
            -- bounded handoff until the widget is live, then never rewrite
            -- that object again while the panel remains open.
            local scheduled = pcall(function()
                ExecuteInGameThreadWithDelay(150, function()
                    restore_profile_password(object, "DragonLink-Connect widget-ready " .. class_path)
                end)
            end)
            if not scheduled then
                restore_profile_password(object, "DragonLink-Connect creation fallback " .. class_path)
            end
        end)
    end)
end

local password_notify_ok, password_notify_error = observe_password_class(EDITABLE_TEXT_CLASS)
local password_box_ok, password_box_error = observe_password_class("/Script/UMG.EditableTextBox")
if password_notify_ok or password_box_ok then
    log("DragonLink-Connect password-field observer registered; EditableText="
        .. tostring(password_notify_ok) .. "; EditableTextBox=" .. tostring(password_box_ok))
else
    log("Password-field observers unavailable: " .. tostring(password_notify_error)
        .. "; " .. tostring(password_box_error))
end

-- The Direct panel can already exist before NotifyOnNewObject is registered.
-- A startup scan covers that case. Per-object tracking prevents polling or
-- repeated writes to fields while the player is typing.
local initial_restores = restore_existing_password_fields("startup scan")
log("Startup password-field scan committed " .. tostring(initial_restores) .. " field(s)")
