-- ========================================================
-- DragonCore v4.2 - ITEM WEIGHTS
-- ========================================================
-- Edit the number on the RIGHT side of the = sign.
--
--     0.0  = weightless
--     0.25 = weight of 0.25
--     1.0  = weight of 1.0
--    -1.0  = LEAVE THE GAME / MOD'S EXISTING WEIGHT ALONE
--
-- DragonCore classifies vanilla AND modded items naturally from their
-- ItemData path/name/tags. RuneSchema-style /Game/Mods/<ModName>/ items
-- do not need to be registered anywhere.
-- ========================================================

return {
    -- Quick option: makes every NON-EQUIPMENT item weightless.
    -- Leave false to use the detailed values below.
    ZeroWeightNonEquipment = false,

    -- Used only when DragonCore cannot identify the item's group.
    Defaults = {
        Vanilla = 0.0,
        Modded = 0.0,
    },

    -- -------------------- MAGIC ---------------------------
    Magic = {
        Rune = 0.0,
        Catalyst = 0.0,
        MagicComponent = 0.0,
        Essence = 0.0,
    },

    -- ------------------ AMMUNITION ------------------------
    Ammunition = {
        Ammo = -1.0,
        Arrow = -1.0,
        Bolt = -1.0,
        Throwable = 0.0,
    },

    -- ------------------- CURRENCY -------------------------
    Currency = {
        Currency = 0.0,
        Token = 0.0,
    },

    -- ----------------- CONSUMABLES ------------------------
    Consumables = {
        LootPack = 0.0,
        TreasureBag = 0.0,
        Food = 0.0,
        Drink = 0.0,
        Potion = 0.0,
        Bandage = 0.0,
        Scroll = 0.0,
        Tome = 0.0,
        Consumable = 0.0,
    },

    -- ------------------ RESOURCES -------------------------
    Resources = {
        Log = 0.0,
        Plank = 0.0,
        Ore = 0.0,
        Bar = 0.0,
        Stone = 0.0,
        Clay = 0.0,
        Sand = 0.0,
        Coal = 0.0,
        Gem = 0.0,
        Salvage = 0.0,
        Bone = 0.0,
        AnimalMaterial = 0.0,
        MonsterMaterial = 0.0,
        Hide = 0.0,
        Cloth = 0.0,
        Leather = 0.0,
        CraftingComponent = 0.0,
        Resource = 0.0,
    },

    -- ---------------- FARMING / FISHING -------------------
    FarmingFishing = {
        Seed = 0.0,
        Sapling = 0.0,
        FarmingMaterial = 0.0,
        Compost = 0.0,
        Fertilizer = 0.0,
        Fish = 0.0,
        Bait = 0.0,
    },

    -- --------------- CRAFTING / BUILDING -----------------
    CraftingBuilding = {
        Plan = 0.0,
        Recipe = 0.0,
        Decoration = 0.0,
        Furniture = 0.0,
        BuildingMaterial = 0.0,
    },

    Protected = {
        Quest = -1.0,
        Key = -1.0,
        Artifact = -1.0,
        Mount = -1.0,
        Pet = -1.0,
    },

    -- ------------------- EQUIPMENT ------------------------
    -- Each equipment group has its own switch and weight.
    Equipment = {
        All = {
            Enabled = false,
            Weight = -1.0,
        },
        Weapons = {
            Enabled = false,
            Weight = -1.0,
        },
        Armour = {
            Enabled = false,
            Weight = -1.0,
        },
        Tools = {
            Enabled = false,
            Weight = -1.0,
        },
        Shields = {
            Enabled = false,
            Weight = -1.0,
        },
        Jewellery = {
            Enabled = false,
            Weight = -1.0,
        },
        HeldItems = {
            Enabled = false,
            Weight = -1.0,
        },
    },

    -- ---------------- CUSTOM OVERRIDES --------------------
    -- Exact overrides always win over the group settings above.
    Custom = {
        ByName = {
            -- ["ITEM_Example"] = 0.0,
        },
        ByPath = {
            -- ["/Game/Mods/MyMod/Gameplay/Items/ITEM_Example.ITEM_Example"] = 0.0,
        },
    },
}
