return {
    IP = "",
    PASSWORD = "",
    SERVER_TYPE = "normal",
    ENABLE_LAST_SERVER = false,
    ENABLE_DIAGNOSTIC_LOG = false
}
