-- ========================================================
-- DragonCore/Scripts/modules/core/classifier.lua
-- Shared ItemData classification engine
-- ========================================================

local Classifier = {}

function Classifier.Attach(Core)
    function Core:GetLowerTagName(CategoryTag)
        if not CategoryTag then return nil end
        local success, tagName = pcall(function()
            return CategoryTag:ToString() or tostring(CategoryTag.TagName) or tostring(CategoryTag)
        end)
        return success and tagName and string.lower(tagName) or nil
    end

    function Core:GetItemFullName(ItemData)
        if not self:IsValid(ItemData) then return nil end
        local nameOk, name = pcall(ItemData.GetFullName, ItemData)
        return nameOk and name or nil
    end

    function Core:GetItemName(ItemData)
        if not ItemData then return "nil" end

        local fullName = self:GetItemFullName(ItemData)
        if fullName then
            local match = string.match(fullName, "([^/%.]+)%.[^/%.]+$") or string.match(fullName, "([^/]+)$")
            if match then return match end
        end

        local nameOk, name = pcall(function()
            return (ItemData.Name and ItemData.Name:ToString()) or (ItemData.GetName and ItemData:GetName():ToString())
        end)

        return (nameOk and name) or "unknown"
    end


    function Core:GetItemObjectPath(ItemData)
        local fullName = self:GetItemFullName(ItemData) or ""
        local path = tostring(fullName):match("(/[^%s]+)$") or tostring(fullName)
        return path:gsub("\\", "/")
    end

    function Core:GetSchemaModIdentity(ItemData)
        local path = self:GetItemObjectPath(ItemData)
        local modName = path:match("^/Game/Mods/([^/]+)/") or path:match("^/Mods/([^/]+)/")
        if modName then return true, modName, path end
        return false, nil, path
    end

    function Core:MatchesAnyKeyword(str, keywords)
        if not str then return false end
        local haystack = string.lower(tostring(str))
        for _, keyword in ipairs(keywords or {}) do
            if string.find(haystack, string.lower(keyword), 1, true) then return true end
        end
        return false
    end

    function Core:GetFilterTagsLower(ItemData)
        local filterOk, tagString = pcall(function() return ItemData:GetItemFilterTags():ToString() end)
        if filterOk and tagString then return string.lower(tagString) end
        return ""
    end

    function Core:GetEquipmentType(ItemData)
        if not self:IsValid(ItemData) then return nil end

        local fullName = string.lower(self:GetItemFullName(ItemData) or "")
        local lowerCategory = self:GetLowerTagName(ItemData.Category) or ""
        local filterTags = self:GetFilterTagsLower(ItemData)

        -- Check very specific classes first.
        if self:MatchesAnyKeyword(fullName, {"/equipment/shield/", "/shield/"})
            or self:MatchesAnyKeyword(lowerCategory, {"shield"})
            or self:MatchesAnyKeyword(filterTags, {"shield"}) then
            return "Shield"
        end

        if self:MatchesAnyKeyword(fullName, {"/equipment/ring/", "/equipment/amulet/", "/equipment/jewellery/", "/equipment/jewelry/", "/ring/", "/amulet/"})
            or self:MatchesAnyKeyword(lowerCategory, {"ring", "amulet", "jewellery", "jewelry"})
            or self:MatchesAnyKeyword(filterTags, {"ring", "amulet", "jewellery", "jewelry"}) then
            return "Jewellery"
        end

        if self:MatchesAnyKeyword(fullName, {
            "/equipment/weapon/", "/equipment/held/dagger/", "/equipment/held/greatsword/",
            "/equipment/held/mace/", "/equipment/held/sword/", "/equipment/held/bow/",
            "/equipment/held/staff/", "/weapon/"
        })
            or self:MatchesAnyKeyword(lowerCategory, {"weapon", "dagger", "greatsword", "mace", "sword", "bow", "staff"})
            or self:MatchesAnyKeyword(filterTags, {"weapon", "dagger", "greatsword", "mace", "sword", "bow", "staff"}) then
            return "Weapon"
        end

        if self:MatchesAnyKeyword(fullName, {
            "/equipment/tool/", "/equipment/held/hatchet/", "/equipment/held/pickaxe/",
            "/equipment/held/fishingnet/", "/equipment/held/fishingrod/", "/tool/"
        })
            or self:MatchesAnyKeyword(lowerCategory, {"tool", "hatchet", "pickaxe", "fishingnet", "fishingrod"})
            or self:MatchesAnyKeyword(filterTags, {"tool", "hatchet", "pickaxe", "fishingnet", "fishingrod"}) then
            return "Tool"
        end

        if self:MatchesAnyKeyword(fullName, {
            "/equipment/body/", "/equipment/cape/", "/equipment/head/", "/equipment/legs/",
            "/armour/", "/armor/"
        })
            or self:MatchesAnyKeyword(lowerCategory, {"armour", "armor", "head", "body", "legs", "cape"})
            or self:MatchesAnyKeyword(filterTags, {"armour", "armor", "head", "body", "legs", "cape"}) then
            return "Armour"
        end

        if self:MatchesAnyKeyword(fullName, {"/equipment/held/", "/held/"})
            or self:MatchesAnyKeyword(lowerCategory, {"held", "bucket"})
            or self:MatchesAnyKeyword(filterTags, {"held", "bucket"}) then
            return "HeldItem"
        end

        if self:MatchesAnyKeyword(fullName, {"/equipment/"})
            or self:MatchesAnyKeyword(lowerCategory, {"equipment"})
            or self:MatchesAnyKeyword(filterTags, {"equipment"}) then
            return "Equipment"
        end

        return nil
    end

    function Core:IsEquipmentByPathOrTag(ItemData)
        if not self:IsValid(ItemData) then return false end
        if self:GetEquipmentType(ItemData) then return true end

        local fullName = string.lower(self:GetItemFullName(ItemData) or "")
        local lowerCategory = self:GetLowerTagName(ItemData.Category) or ""
        local filterTags = self:GetFilterTagsLower(ItemData)

        local equipmentPaths = {
            "/equipment/body/", "/equipment/cape/", "/equipment/head/", "/equipment/legs/",
            "/equipment/jewellery/", "/equipment/jewelry/", "/equipment/ring/", "/equipment/amulet/",
            "/equipment/shield/", "/equipment/weapon/", "/equipment/tool/",
            "/equipment/held/bucket/", "/equipment/held/dagger/", "/equipment/held/fishingnet/",
            "/equipment/held/fishingrod/", "/equipment/held/greatsword/", "/equipment/held/hatchet/",
            "/equipment/held/mace/", "/equipment/held/pickaxe/"
        }

        if self:MatchesAnyKeyword(fullName, equipmentPaths) then return true end

        local equipmentTags = {
            "equipment", "weapon", "armour", "armor", "tool", "head", "body", "legs", "cape",
            "jewellery", "jewelry", "hatchet", "pickaxe", "bucket", "dagger", "greatsword",
            "mace", "fishingnet", "fishingrod", "shield", "ring", "amulet"
        }

        if self:MatchesAnyKeyword(lowerCategory, equipmentTags) then return true end
        if self:MatchesAnyKeyword(filterTags, {"equipment", "weapon", "armour", "armor", "tool"}) then return true end

        return false
    end

    function Core:ClassifyItem(ItemData)
        if not self:IsValid(ItemData) then
            return { Name = "invalid", FullName = "", ObjectPath = "", Category = "Default", IsEquipment = false, EquipmentType = nil, IsModItem = false, ModName = nil }
        end

        local fullNameRaw = self:GetItemFullName(ItemData) or ""
        local fullName = string.lower(fullNameRaw)
        local itemName = self:GetItemName(ItemData)
        local itemNameLower = string.lower(itemName or "")
        local lowerCategory = self:GetLowerTagName(ItemData.Category) or ""
        local filterTags = self:GetFilterTagsLower(ItemData)
        local isModItem, modName, objectPath = self:GetSchemaModIdentity(ItemData)

        local function Result(category)
            return { Name = itemName, FullName = fullNameRaw, ObjectPath = objectPath, Category = category, IsEquipment = false, EquipmentType = nil, IsModItem = isModItem, ModName = modName }
        end

        local function Match(words)
            return self:MatchesAnyKeyword(fullName, words)
                or self:MatchesAnyKeyword(itemNameLower, words)
                or self:MatchesAnyKeyword(lowerCategory, words)
                or self:MatchesAnyKeyword(filterTags, words)
        end

        local equipmentType = self:GetEquipmentType(ItemData)
        local isEquipment = equipmentType ~= nil or self:IsEquipmentByPathOrTag(ItemData)
        if isEquipment then
            return {
                Name = itemName,
                FullName = fullNameRaw,
                ObjectPath = objectPath,
                Category = "Equipment",
                IsEquipment = true,
                EquipmentType = equipmentType or "Equipment",
                IsModItem = isModItem,
                ModName = modName
            }
        end

        -- Protected and unique content first.
        if Match({"/quest/", "/items/quest/", "_quest_", "journalitem"}) then return Result("Quest") end
        if Match({"/resources/key/", "/items/key/", "_key_", "postbox"}) then return Result("Key") end
        if Match({"artifact", "relic", "uniqueitem"}) then return Result("Artifact") end
        if Match({"/mounts/", "mountunlocker", "mount_"}) then return Result("Mount") end
        if Match({"/pets/", "petunlocker", "_pet_"}) then return Result("Pet") end

        -- Currency and magic.
        if Match({"token", "eventcurrency"}) then return Result("Token") end
        if Match({"/currency/", "/items/currency/", "_currency_", "coin", "coins", "chit"}) then return Result("Currency") end
        if string.find(fullNameRaw, "ITEM_Rune_", 1, true) or string.find(itemName, "ITEM_Rune_", 1, true) then return Result("Rune") end
        if Match({"catalyst", "talisman", "focuscomponent"}) then return Result("Catalyst") end
        if Match({"magiccomponent", "magical_component", "anima-infused", "anima_infused", "rune essence", "runeessence"}) then return Result("MagicComponent") end
        if Match({"essence"}) then return Result("Essence") end

        -- Ammo families.
        if Match({"/arrows/", "_arrow_", "arrows_"}) then return Result("Arrow") end
        if Match({"/bolts/", "_bolt_", "bolts_"}) then return Result("Bolt") end
        if Match({"throwing", "throwable", "javelin", "dart"}) then return Result("Throwable") end
        if Match({"/equipment/ammo/", "/items/ammo/", "/ammo/", "_ammo_"}) then return Result("Ammo") end

        -- Plans, recipes, and build/decor content.
        if Match({"da_consumable_plan_", "/plans/", " plan_", "_plan_"}) then return Result("Plan") end
        if Match({"recipe", "recipeunlocker"}) then return Result("Recipe") end
        if Match({"/decorations/", "decoration"}) then return Result("Decoration") end
        if Match({"furniture", "chair", "table", "bed", "cabinet"}) then return Result("Furniture") end
        if Match({"buildingmaterial", "buildmaterial", "buildpiece", "/building/"}) then return Result("BuildingMaterial") end

        -- Consumables, ordered from specific to broad.
        if Match({"treasurebag", "treasure_bag", "treasure bag"}) then return Result("TreasureBag") end
        if Match({"itememitter", "/lootpack/", "lootpack", "_pack.", "rewardpack"}) then return Result("LootPack") end
        if Match({"/bandage/", "_bandage_", "bandage"}) then return Result("Bandage") end
        if Match({"/scroll/", "_scroll_", "scroll"}) then return Result("Scroll") end
        if Match({"/tome/", "/tomes/", "_tome_", "skilltome"}) then return Result("Tome") end
        if Match({"/potion/", "_potion_"}) then return Result("Potion") end
        if Match({"/drink/", "_drink_", "beverage", "tea_"}) then return Result("Drink") end
        if Match({"/food/", "_food_", "meat_", "egg_", "cooked", "roast"}) then return Result("Food") end

        -- Farming and fishing.
        if Match({"/items/fishes/", "/fishes/", "_fish_", "fish_"}) then return Result("Fish") end
        if Match({"/baits/", "_bait", " bait"}) then return Result("Bait") end
        if Match({"/treeplanting/", "sapling"}) then return Result("Sapling") end
        if Match({"/farming/seeds/", "_seed", "seed_"}) then return Result("Seed") end
        if Match({"fertilizer", "fertiliser"}) then return Result("Fertilizer") end
        if Match({"compost"}) then return Result("Compost") end
        if Match({"/farming/", "farmmaterial", "farmingmaterial"}) then return Result("FarmingMaterial") end

        -- Resource families.
        if Match({"/plank", "_plank_", "plank_"}) then return Result("Plank") end
        if Match({"/wood/", "_wood_", "_logs", "log_"}) then return Result("Log") end
        if Match({"/metal/", "_bar", "bar_", "ingot"}) then return Result("Bar") end
        if Match({"coal"}) then return Result("Coal") end
        if Match({"clay"}) then return Result("Clay") end
        if Match({"sandstone", "/sand/", "_sand_"}) then return Result("Sand") end
        if Match({"stone", "granite", "limestone", "gypsum"}) then return Result("Stone") end
        if Match({"/ore/", "_ore", "ore_", "/mineral/"}) then return Result("Ore") end
        if Match({"/gem/", "/gems/", "opal", "jade", "sapphire", "emerald", "ruby", "diamond"}) then return Result("Gem") end
        if Match({"salvage", "scrap"}) then return Result("Salvage") end
        if Match({"/bones/", "_bone", "bones_", "ashes"}) then return Result("Bone") end
        if Match({"hide", "pelt", "fur", "skin"}) then return Result("Hide") end
        if Match({"leather"}) then return Result("Leather") end
        if Match({"cloth", "textile", "wool", "linen"}) then return Result("Cloth") end
        if Match({"animalmaterial", "/animal/", "animal_scrap", "animal scrap", "horn", "feather"}) then return Result("AnimalMaterial") end
        if Match({"monster_material", "monstermaterial", "chitin", "carapace", "scale", "ectoplasm", "demonic"}) then return Result("MonsterMaterial") end
        if Match({"component", "masterworks", "craftingcomponent"}) then return Result("CraftingComponent") end

        if Match({"/items/consumables/", "/consumables/", "consumable"}) then return Result("Consumable") end
        if Match({"/items/resources/", "/resources/", "resource", "material", "ingredient"}) then return Result("Resource") end

        return Result("Default")
    end
end

return Classifier
