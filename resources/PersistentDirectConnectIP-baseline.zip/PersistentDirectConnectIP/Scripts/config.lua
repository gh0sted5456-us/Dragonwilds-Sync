-- Configuration for PersistentDirectConnectIP
return {
    IP = "",
    PASSWORD = "",
    SERVER_TYPE = "normal",  -- options: normal, hardcore, creative
    ENABLE_LAST_SERVER = true,
    ENABLE_DIAGNOSTIC_LOG = false
}
