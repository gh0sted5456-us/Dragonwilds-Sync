-- ========================================================
-- DragonCore v4.2 - STACK SIZES
-- ========================================================
-- Edit the number on the RIGHT side of the = sign.
--
-- Examples:
--     Rune = 9999,       -- runes can stack to 9,999
--     Ore = 500,         -- ore can stack to 500
--     Food = 100,        -- food can stack to 100
--
-- DragonCore classifies vanilla AND modded items naturally from their
-- ItemData path/name/tags. RuneSchema-style /Game/Mods/<ModName>/ items
-- do not need to be registered anywhere.
--
-- CUSTOM ITEMS:
-- Use Custom.ByName or Custom.ByPath at the bottom when one specific item
-- should ignore its normal group setting.
-- ========================================================

return {
    -- Used only when DragonCore cannot identify the item's group.
    Defaults = {
        Vanilla = 300,
        Modded = 300,
    },

    -- -------------------- MAGIC ---------------------------
    Magic = {
        Rune = 9999,
        Catalyst = 300,
        MagicComponent = 300,
        Essence = 300,
    },

    -- ------------------ AMMUNITION ------------------------
    Ammunition = {
        Ammo = 9999,
        Arrow = 9999,
        Bolt = 9999,
        Throwable = 300,
    },

    -- ------------------- CURRENCY -------------------------
    Currency = {
        Currency = 99999,
        Token = 99999,
    },

    -- ----------------- CONSUMABLES ------------------------
    Consumables = {
        LootPack = 300,
        TreasureBag = 300,
        Food = 300,
        Drink = 300,
        Potion = 300,
        Bandage = 300,
        Scroll = 300,
        Tome = 300,
        Consumable = 300,
    },

    -- ------------------ RESOURCES -------------------------
    Resources = {
        Log = 300,
        Plank = 300,
        Ore = 300,
        Bar = 300,
        Stone = 300,
        Clay = 300,
        Sand = 300,
        Coal = 300,
        Gem = 300,
        Salvage = 300,
        Bone = 300,
        AnimalMaterial = 300,
        MonsterMaterial = 300,
        Hide = 300,
        Cloth = 300,
        Leather = 300,
        CraftingComponent = 300,
        Resource = 300,
    },

    -- ---------------- FARMING / FISHING -------------------
    FarmingFishing = {
        Seed = 300,
        Sapling = 300,
        FarmingMaterial = 300,
        Compost = 300,
        Fertilizer = 300,
        Fish = 300,
        Bait = 300,
    },

    -- --------------- CRAFTING / BUILDING -----------------
    CraftingBuilding = {
        Plan = 300,
        Recipe = 300,
        Decoration = 300,
        Furniture = 300,
        BuildingMaterial = 300,
    },

    -- These are deliberately conservative.
    Protected = {
        Quest = 1,
        Key = 1,
        Artifact = 1,
        Mount = 1,
        Pet = 1,
    },

    -- ------------------- EQUIPMENT ------------------------
    Equipment = {
        -- false = weapons/armour/tools/etc. keep normal one-at-a-time stacks.
        Enabled = false,
        StackSize = 1,
    },

    -- --------------------- RULES --------------------------
    Rules = {
        -- false is the safe/default behavior. A vanilla item authored with a
        -- stack size of 1 stays at 1 unless it has an exact Custom override.
        AllowNativeSingleStackItemsToStack = false,

        -- false = group settings may RAISE an authored stack size, but will
        -- not LOWER an item that another mod/game update already made larger.
        AllowGroupRulesToLowerHigherStacks = false,

        -- Optional universal stack mode. Usually leave this false.
        MaxMode = false,
        MaxModeStackSize = 99999,
    },

    -- ---------------- CUSTOM OVERRIDES --------------------
    -- Exact overrides always win over the group settings above.
    Custom = {
        ByName = {
            -- ["ITEM_Example"] = 500,
        },

        ByPath = {
            -- ["/Game/Mods/MyMod/Gameplay/Items/ITEM_Example.ITEM_Example"] = 500,
        },
    },
}
