DragonCore v4.2.0 Classic
=========================

PURPOSE
-------
DragonCore does two things only:
  1. Configurable item stack sizes.
  2. Configurable item weights.

There is no persistent item cache, item registry, PAK scanner, census,
recovery system, report system, or inventory manager.

FILE LAYOUT
-----------
DragonCore/
  enabled.txt
  Scripts/
    main.lua                 <- MUST stay here
    config.lua               <- Player / Server mode and master switches
    stacks.lua               <- detailed stack configuration
    weights.lua              <- detailed weight configuration
    modules/
      core/
        classifier.lua
        network.lua
      features/
        stacks.lua
        weights.lua

INSTALL MODE
------------
Open Scripts/config.lua.

Mode = "Player"
  Use on a normal game installation.
  ACTIVE in single-player.
  ACTIVE when this player hosts co-op (ListenServer).
  PASS-THROUGH when this player joins another host/dedicated server.

Mode = "Server"
  Use on the dedicated-server installation.
  DragonCore treats that installation as dedicated-server authority.

STACK CONFIG
------------
Open Scripts/stacks.lua.
The file is grouped into Magic, Ammunition, Currency, Consumables,
Resources, Farming/Fishing, Crafting/Building, Protected, and Equipment.

Exact item overrides are available at the bottom through:
  Custom.ByName
  Custom.ByPath

WEIGHT CONFIG
-------------
Open Scripts/weights.lua.
Values use:
  0.0  = weightless
 -1.0  = preserve authored/game weight
 other non-negative numbers = exact configured weight

Equipment has separate controls for weapons, armour, tools, shields,
jewellery, held items, and a master equipment fallback.

MODDED ITEMS
------------
DragonCore does not require a ModItems registry.
When Unreal loads ItemData, DragonCore classifies it naturally from its
path, name, category, and tags. RuneSchema-style items under
/Game/Mods/<ModName>/ are recognized as modded items automatically and
receive the same category rules as vanilla items.

MULTIPLAYER CLEAN BREAK
-----------------------
The three stack hooks stay installed for the UE4SS process and check the
current local role before changing anything.

Player mode:
  Standalone   = ACTIVE
  ListenServer = ACTIVE
  RemoteClient = PASS-THROUGH

Before normal map travel, DragonCore restores only ItemData values that
DragonCore itself changed. This prevents a prior single-player/host session
from carrying stack or weight property edits into a remote-client session.
The original values are held only in a weak in-memory table; nothing is
written to disk and nothing persists across a game restart.
