-- ========================================================
-- DragonCore v4.2 - lightweight install/network role gate
-- ========================================================
-- config.lua chooses "Player" or "Server".
--
-- Server: dedicated-server authority; always active.
-- Player: active in Standalone / ListenServer, pass-through as RemoteClient.
-- ========================================================

local Network = {}

local function valid(object)
    if not object then return false end
    local ok, result = pcall(function() return object:IsValid() end)
    return ok and result == true
end

local function delay(ms, callback)
    if type(ExecuteInGameThreadWithDelay) == "function" then
        ExecuteInGameThreadWithDelay(ms, callback)
        return true
    end
    if type(ExecuteWithDelay) == "function" then
        ExecuteWithDelay(ms, callback)
        return true
    end
    return false
end

local function getKismet()
    local ok, object = pcall(StaticFindObject, "/Script/Engine.Default__KismetSystemLibrary")
    if ok and valid(object) then return object end
    return nil
end

local function normalizeInstallMode(value)
    local mode = string.lower(tostring(value or "Player"))
    if mode == "server" then return "Server" end
    return "Player"
end

function Network.Attach(Core)
    Core.InstallMode = normalizeInstallMode(Core.Config.Mode)
    Core.NetworkMode = Core.InstallMode == "Server" and "DedicatedServer" or "Unknown"
    Core.NetworkPollGeneration = 0

    function Core:ShouldModify()
        if self.Config.Enabled == false then return false end

        -- Dedicated-server installs are explicit. No multiplayer guessing needed.
        if self.InstallMode == "Server" then return true end

        -- Normal/player installs modify only worlds owned by this machine.
        return self.NetworkMode == "Standalone" or self.NetworkMode == "ListenServer"
    end

    function Core:DetectNetworkMode(world)
        if not valid(world) then return "Unknown" end
        local lib = getKismet()
        if not lib then return "Unknown" end

        local okDedicated, dedicated = pcall(function() return lib:IsDedicatedServer(world) end)
        local okStandalone, standalone = pcall(function() return lib:IsStandalone(world) end)
        local okServer, server = pcall(function() return lib:IsServer(world) end)
        if not okDedicated or not okStandalone or not okServer then return "Unknown" end

        if dedicated == true then return "DedicatedServer" end
        if standalone == true then return "Standalone" end
        if server == true then return "ListenServer" end
        return "RemoteClient"
    end

    function Core:SetNetworkMode(mode)
        if self.InstallMode == "Server" then return true end
        if not mode or mode == "Unknown" then return false end

        local changed = self.NetworkMode ~= mode
        local wasActive = self:ShouldModify()
        self.NetworkMode = mode
        local isActive = self:ShouldModify()

        if changed then
            self:Log("Player role: " .. tostring(mode) .. " | " .. (isActive and "ACTIVE" or "PASS-THROUGH"))
        end

        -- If we stopped owning the world, restore only values DragonCore itself changed.
        if wasActive and not isActive then
            self:RestoreOriginalValues()
        end

        -- If we now own the world, apply the configured values to ItemData already in memory.
        if isActive and (changed or not wasActive) then
            self:PatchLoadedItemData()
        end

        return true
    end

    function Core:EvaluateActor(actor)
        if self.InstallMode == "Server" then return true end
        if not valid(actor) then return false end
        local okWorld, world = pcall(function() return actor:GetWorld() end)
        if not okWorld or not valid(world) then return false end
        return self:SetNetworkMode(self:DetectNetworkMode(world))
    end

    function Core:PollNetworkRole(attempt, generation)
        if self.InstallMode == "Server" then return end
        if generation ~= self.NetworkPollGeneration then return end

        for _, className in ipairs({ "DominionPlayerController", "GameStateBase" }) do
            local ok, object = pcall(FindFirstOf, className)
            if ok and valid(object) and self:EvaluateActor(object) then return end
        end

        if (attempt or 0) < 20 then
            delay(750, function() Core:PollNetworkRole((attempt or 0) + 1, generation) end)
        end
    end

    function Core:RestartNetworkPoll()
        if self.InstallMode == "Server" then return end
        self.NetworkPollGeneration = self.NetworkPollGeneration + 1
        local generation = self.NetworkPollGeneration
        delay(400, function() Core:PollNetworkRole(0, generation) end)
    end

    function Core:StartNetworkGate()
        if self.NetworkGateStarted then return end
        self.NetworkGateStarted = true

        if self.InstallMode == "Server" then
            self.NetworkMode = "DedicatedServer"
            self:Log("Install mode: Server | DedicatedServer authority ACTIVE")
            self:PatchLoadedItemData()
            return
        end

        self:Log("Install mode: Player | waiting for local world role")

        -- Before travel, return any ItemData DragonCore changed to its original
        -- value. This makes joining another player's server a true pass-through.
        if type(RegisterLoadMapPreHook) == "function" then
            pcall(RegisterLoadMapPreHook, function()
                Core.NetworkPollGeneration = Core.NetworkPollGeneration + 1
                Core:RestoreOriginalValues()
                Core.NetworkMode = "Transition"
            end)
        end

        -- BeginPlay identifies Standalone / ListenServer / RemoteClient.
        if type(RegisterBeginPlayPostHook) == "function" then
            pcall(RegisterBeginPlayPostHook, function(actor)
                Core:EvaluateActor(actor)
            end)
        end

        -- Fallback for load orders where the useful BeginPlay callback is late.
        if type(RegisterLoadMapPostHook) == "function" then
            pcall(RegisterLoadMapPostHook, function()
                Core.NetworkMode = "Unknown"
                Core:RestartNetworkPoll()
            end)
        end

        self:RestartNetworkPoll()
    end
end

return Network
