### RuneSchema – Quick Changelog

- Added `mods.txt` support for RuneSchema mod load order and disabling mods.
- Added persistent runtime `Actor` spawning for trees, ore, stone, and similar resources.
- Harvested resources can remain removed after save reload.
- Added configurable reload behavior:
  - `RespawnOnReload`
  - `RespawnAfterSeconds`
- Extended persistence tracking to RuneSchema AI spawns.
- Moved generated persistence state into each mod’s `config/spawn_persistence.json`.
- Added automatic migration from the former root persistence file.
- Persistence records now identify their source mod, spawn file, entry ID, class, type, and scale.
- Added per-entry `Scale` support for resources and AI.
- Added `DropIncreasePercent` for resource quantity scaling.
- Resource drops can automatically scale with object size when `DropIncreasePercent` is omitted.
- Fixed warnings caused by per-mod `config` folders being mistaken for unsupported loader folders.
- Preserved all existing RuneSchema spawn properties and `mods.txt` functionality.