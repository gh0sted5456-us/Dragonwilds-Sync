-- ========================================================
-- DragonCore v4.2 - stack modifier
-- ========================================================

local Stacks = {}

local CATEGORY_SECTIONS = {
    "Magic",
    "Ammunition",
    "Currency",
    "Consumables",
    "Resources",
    "FarmingFishing",
    "CraftingBuilding",
    "Protected",
}

local function clamp(value, fallback)
    local n = tonumber(value)
    if not n or n < 1 then return fallback end
    return math.floor(n)
end

local function flattenCategories(config)
    local out = {}
    for _, sectionName in ipairs(CATEGORY_SECTIONS) do
        local section = config[sectionName]
        if type(section) == "table" then
            for category, value in pairs(section) do
                out[category] = clamp(value, nil)
            end
        end
    end
    return out
end

local function explicitOverride(meta, config)
    local custom = config.Custom or {}
    local byPath = type(custom.ByPath) == "table" and custom.ByPath or {}
    local byName = type(custom.ByName) == "table" and custom.ByName or {}

    if meta.FullName and byPath[meta.FullName] ~= nil then
        return clamp(byPath[meta.FullName], nil), true
    end
    if meta.ObjectPath and byPath[meta.ObjectPath] ~= nil then
        return clamp(byPath[meta.ObjectPath], nil), true
    end
    if meta.Name and byName[meta.Name] ~= nil then
        return clamp(byName[meta.Name], nil), true
    end
    return nil, false
end

function Stacks.Prepare(Core)
    Core.StackLimits = flattenCategories(Core.StackConfig)
end

function Stacks.GetConfiguredLimit(ItemData, Core)
    local meta = Core:ClassifyItem(ItemData)
    local config = Core.StackConfig

    local override, explicit = explicitOverride(meta, config)
    if explicit then return override, meta, true end

    local rules = config.Rules or {}
    if rules.MaxMode == true then
        return clamp(rules.MaxModeStackSize, 99999), meta, false
    end

    if meta.IsEquipment then
        local equipment = config.Equipment or {}
        if equipment.Enabled == true then
            return clamp(equipment.StackSize, 1), meta, false
        end
        return 1, meta, false
    end

    local categoryLimit = Core.StackLimits[meta.Category]
    if categoryLimit then return categoryLimit, meta, false end

    local defaults = config.Defaults or {}
    if meta.IsModItem then return clamp(defaults.Modded, 300), meta, false end
    return clamp(defaults.Vanilla, 300), meta, false
end

function Stacks.GetEffectiveLimit(ItemData, Core, currentValue)
    local target, meta, explicit = Stacks.GetConfiguredLimit(ItemData, Core)
    local current = tonumber(currentValue)
    if not target then return current, meta, explicit end

    if meta.IsEquipment and (Core.StackConfig.Equipment or {}).Enabled ~= true and not explicit then
        return current or 1, meta, explicit
    end

    local rules = Core.StackConfig.Rules or {}

    -- Safe default: native single-stack content remains single-stack unless
    -- the user opts in or gives that item an exact Custom override.
    if current and current <= 1 and target > 1
        and rules.AllowNativeSingleStackItemsToStack ~= true
        and explicit ~= true then
        return current, meta, explicit
    end

    -- Exact Custom item overrides are exact by design.
    if explicit then return target, meta, explicit end

    -- Group rules normally raise limits without lowering another mod's value.
    if current and rules.AllowGroupRulesToLowerHigherStacks ~= true and target < current then
        return current, meta, explicit
    end

    return target, meta, explicit
end

function Stacks.PatchItemData(ItemData, Core)
    if Core.Config.Stacks == false or not Core:ShouldModify() or not Core:IsValid(ItemData) then return false end

    local okCurrent, current = pcall(function() return ItemData.MaxStackSize end)
    if not okCurrent or current == nil then return false end

    local target, meta = Stacks.GetEffectiveLimit(ItemData, Core, current)
    if target == nil or tonumber(target) == tonumber(current) then return false end

    Core:RememberOriginal(ItemData, "MaxStackSize", current)

    local ok = pcall(function() ItemData.MaxStackSize = target end)
    if ItemData.SetPropertyValue then
        pcall(function() ItemData:SetPropertyValue("MaxStackSize", target) end)
    end

    if ok then
        local modText = meta.IsModItem and (" mod=" .. tostring(meta.ModName)) or ""
        Core:Debug("stack " .. tostring(meta.Name) .. " [" .. tostring(meta.Category) .. "] " .. tostring(current) .. " -> " .. tostring(target) .. modText)
    end
    return ok
end

function Stacks.RegisterHooks(Core)
    Core:RegisterStackHook("/Script/Dominion.Item:SetStackSize", function(Context)
        if not Core:ShouldModify() then return end
        local item = Context and Context:get() or nil
        if not Core:IsValid(item) or not Core:IsValid(item.ItemData) then return end
        Stacks.PatchItemData(item.ItemData, Core)
    end)

    Core:RegisterStackHook("/Script/Dominion.ItemData:GetMaxStackSize", function(Context, ReturnValue)
        if not Core:ShouldModify() then return end
        local data = Context and Context:get() or nil
        if not Core:IsValid(data) or not ReturnValue or not ReturnValue.get or not ReturnValue.set then return end

        local current = ReturnValue:get()
        local target = Stacks.GetEffectiveLimit(data, Core, current)
        if target ~= nil and tonumber(target) ~= tonumber(current) then
            ReturnValue:set(target)
        end
    end)

    Core:RegisterStackHook("/Script/Dominion.Item:GetStackFreeSpace", function(Context, ReturnValue)
        if not Core:ShouldModify() then return end
        local item = Context and Context:get() or nil
        if not Core:IsValid(item) or not Core:IsValid(item.ItemData) or not ReturnValue or not ReturnValue.set then return end

        local currentMax = nil
        pcall(function() currentMax = item.ItemData.MaxStackSize end)
        local limit = Stacks.GetEffectiveLimit(item.ItemData, Core, currentMax)
        local count = tonumber(item.Count) or 0
        local free = (tonumber(limit) or tonumber(currentMax) or 1) - count
        if free < 0 then free = 0 end
        ReturnValue:set(free)
    end)
end

return Stacks
