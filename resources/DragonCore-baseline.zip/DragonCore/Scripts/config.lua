-- ========================================================
-- DragonCore v4.2 - main configuration
-- ========================================================
-- This file only controls DragonCore itself.
-- Detailed stack sizes live in:  Scripts/stacks.lua
-- Detailed item weights live in: Scripts/weights.lua
-- ========================================================

return {
    Enabled = true,

    -- "Player"
    --   Use this on a normal game installation.
    --   DragonCore is ACTIVE in single-player and while YOU host co-op.
    --   DragonCore becomes PASS-THROUGH when you join somebody else's game.
    --
    -- "Server"
    --   Use this on the dedicated-server installation.
    --   DragonCore treats this installation as the authority and stays ACTIVE.
    Mode = "Player",

    Stacks = true,
    Weights = true,

    -- Extra classification / network messages in the UE4SS console.
    Debug = false,
}
