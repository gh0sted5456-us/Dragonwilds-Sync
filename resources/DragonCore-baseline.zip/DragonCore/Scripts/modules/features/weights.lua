-- ========================================================
-- DragonCore v4.2 - weight modifier
-- ========================================================

local Weights = {}

local CATEGORY_SECTIONS = {
    "Magic",
    "Ammunition",
    "Currency",
    "Consumables",
    "Resources",
    "FarmingFishing",
    "CraftingBuilding",
    "Protected",
}

local function validWeight(value, fallback)
    local n = tonumber(value)
    if n == nil or n < -1.0 then return fallback end
    return n
end

local function flattenCategories(config)
    local out = {}
    for _, sectionName in ipairs(CATEGORY_SECTIONS) do
        local section = config[sectionName]
        if type(section) == "table" then
            for category, value in pairs(section) do
                out[category] = validWeight(value, nil)
            end
        end
    end
    return out
end

local function explicitOverride(meta, config)
    local custom = config.Custom or {}
    local byPath = type(custom.ByPath) == "table" and custom.ByPath or {}
    local byName = type(custom.ByName) == "table" and custom.ByName or {}

    if meta.FullName and byPath[meta.FullName] ~= nil then
        return validWeight(byPath[meta.FullName], nil), true
    end
    if meta.ObjectPath and byPath[meta.ObjectPath] ~= nil then
        return validWeight(byPath[meta.ObjectPath], nil), true
    end
    if meta.Name and byName[meta.Name] ~= nil then
        return validWeight(byName[meta.Name], nil), true
    end
    return nil, false
end

function Weights.Prepare(Core)
    Core.WeightCategories = flattenCategories(Core.WeightConfig)
end

local function equipmentWeight(meta, config)
    local equipment = config.Equipment or {}

    local all = equipment.All or {}
    local weapons = equipment.Weapons or {}
    local armour = equipment.Armour or {}
    local tools = equipment.Tools or {}
    local shields = equipment.Shields or {}
    local jewellery = equipment.Jewellery or {}
    local heldItems = equipment.HeldItems or {}

    local kind = meta.EquipmentType or "Equipment"
    if kind == "Weapon" and weapons.Enabled == true then return validWeight(weapons.Weight, -1.0) end
    if kind == "Armour" and armour.Enabled == true then return validWeight(armour.Weight, -1.0) end
    if kind == "Tool" and tools.Enabled == true then return validWeight(tools.Weight, -1.0) end
    if kind == "Shield" and shields.Enabled == true then return validWeight(shields.Weight, -1.0) end
    if kind == "Jewellery" and jewellery.Enabled == true then return validWeight(jewellery.Weight, -1.0) end
    if kind == "HeldItem" and heldItems.Enabled == true then return validWeight(heldItems.Weight, -1.0) end
    if all.Enabled == true then return validWeight(all.Weight, -1.0) end
    return -1.0
end

function Weights.GetWeight(ItemData, Core)
    local meta = Core:ClassifyItem(ItemData)
    local config = Core.WeightConfig

    local override, explicit = explicitOverride(meta, config)
    if explicit then return override, meta end

    if meta.IsEquipment then return equipmentWeight(meta, config), meta end
    if config.ZeroWeightNonEquipment == true then return 0.0, meta end

    local categoryWeight = Core.WeightCategories[meta.Category]
    if categoryWeight ~= nil then return categoryWeight, meta end

    local defaults = config.Defaults or {}
    if meta.IsModItem then return validWeight(defaults.Modded, 0.0), meta end
    return validWeight(defaults.Vanilla, 0.0), meta
end

function Weights.PatchItemData(ItemData, Core)
    if Core.Config.Weights == false or not Core:ShouldModify() or not Core:IsValid(ItemData) then return false end

    local target, meta = Weights.GetWeight(ItemData, Core)
    if target == nil or target < 0 then return false end

    local okCurrent, current = pcall(function() return ItemData.Weight end)
    if not okCurrent or current == nil or tonumber(current) == tonumber(target) then return false end

    Core:RememberOriginal(ItemData, "Weight", current)

    local ok = pcall(function() ItemData.Weight = target end)
    if ItemData.SetPropertyValue then
        pcall(function() ItemData:SetPropertyValue("Weight", target) end)
        pcall(function() ItemData:SetPropertyValue("ItemWeight", target) end)
    end

    if ok then
        local modText = meta.IsModItem and (" mod=" .. tostring(meta.ModName)) or ""
        Core:Debug("weight " .. tostring(meta.Name) .. " [" .. tostring(meta.Category) .. "] " .. tostring(current) .. " -> " .. tostring(target) .. modText)
    end
    return ok
end

return Weights
